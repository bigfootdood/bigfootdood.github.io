---
layout: post
title: "iMac Cat Bed"
tags:
 - diy
hero: https://lh3.googleusercontent.com/wKoXSy91KzhKTatcWQ9LFzVp5TFi2e10vxdBUbBSlsgu_6ryu87MsBFuJgtFqluR_UGnUAtdoCUf_piZkaIb7_UlTybrzjD47J33apFGj_X6bIdJcvBHCZTsC91LUkFod8JKmvQ9Xw
overlay: green
published: true
---

I was just given a late model blue iMac G3 which lead to thoughts as to what I could do with my older orange G3.

<iframe src="https://giphy.com/embed/I7rQpNy0j8vPW" width="480" height="204" frameBorder="0" class="giphy-embed" allowFullScreen></iframe>

I give full credit to [this](https://www.youtube.com/watch?v=SdFIi-ZF-6M) video for the idea to make it into a small cat house.

![mira](https://lh3.googleusercontent.com/GioNE_F--DGlm6vtUa5EWP0uGHhqB-c9ne9qYjEBiNZpcfpU5Gr6ouB18u8ejyJpzZ0cB0aErLEbh_czeyBKOP4gBwikB-vnVvyp8niH8iJ7POBL0TFfYNcQOm3GbfUJzKQwqIiUmQ)
