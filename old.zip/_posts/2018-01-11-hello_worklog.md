---
layout: post
title:  "Hello WorkLog!"
tags:
  - github
  - jekyll
hero: assets/img/fireworks.gif
overlay: red
published: true

---

This is my work log, a place where I will be posting markdown notes from projects I will be working on. The idea is that I could document what I do a little more often whether it be working on something new in computer science or just something I find fun or interesting. I want this to be a place where I can organize some of my thoughts and projects.
